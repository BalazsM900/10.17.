﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebAPI_Computer.Context;
using WebAPI_Computer.DTO;
using WebAPI_Computer.Entities;


namespace WebAPI_Computer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComputerController(AppDbContext context) : ControllerBase
    {
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Post([FromBody] PostComputerDTO computerDTO)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (computerDTO is null) { return BadRequest("Nope!"); }

            var computer = new Computer
            {
                Model = computerDTO.Model,
                ManufacturedDate = computerDTO.ManufacturedDate
            };

            await context.Computers.AddAsync(computer);
            await context.SaveChangesAsync();

            return Ok(computer);
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Get()
        {
            var computers = await context.Computers
                .Include(b => b.Room)
                .ToListAsync();
            if (computers is null) { return BadRequest("Again Nope!"); }

            var result = computers.Select(a =>
                new GetComputerDTO
                {
                    Model = a.Model,
                    ManufacturedDate = a.ManufacturedDate
                }).ToList();

            return Ok(result);
        }

        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> Put(int id, [FromBody] PutComputerDTO computerDTO)
        {
            var computer = await context.Computers.SingleOrDefaultAsync(a => a.Id == id);
            if (computer == null) { return BadRequest("Nope!"); }

            computer.Model = computerDTO.Model;
            computer.ManufacturedDate = computerDTO.ManufacturedDate;

            await context.SaveChangesAsync();

            return Ok("Great!");
        }

        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            var computer = await context.Computers.SingleOrDefaultAsync(a => a.Id == id);
            if (computer == null) { return BadRequest("Nope újra!"); }

            context.Computers.Remove(computer);
            await context.SaveChangesAsync();

            return Ok("Nope!");
        }
    }
}
