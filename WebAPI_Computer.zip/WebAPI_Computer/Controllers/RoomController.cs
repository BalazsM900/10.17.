﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebAPI_Computer.Context;
using WebAPI_Computer.DTO;
using WebAPI_Computer.Entities;


namespace WebAPI_Computer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController(AppDbContext context) : ControllerBase
    {
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Post([FromBody] PostRoomDTO roomDTO)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (roomDTO is null) { return BadRequest("Nope!"); }

            var room = new Room
            {
                Name = roomDTO.Name,
                Capacity = roomDTO.Capacity,
            };

            await context.Rooms.AddAsync(room);
            await context.SaveChangesAsync();

            return Ok(room);
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> Get()
        {
            var rooms = await context.Rooms.Include(b => b.User).ToListAsync();
            if (rooms == null) { return BadRequest("Nope"); }

            var result = rooms.Select(b => new GetRoomDTO
            {
               Name = b.Name,
               Capacity = b.Capacity,
            }).ToList();

            return Ok(result);
        }

        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> Put(int id, [FromBody] PutRoomDTO roomDTO)
        {
            var room = await context.Rooms.SingleOrDefaultAsync(a => a.Id == id);
            if (room == null) { return BadRequest("Nope!"); }

            room.Name = roomDTO.Name;
            room.Capacity = roomDTO.Capacity;

            await context.SaveChangesAsync();

            return Ok("Great!");
        }

        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            var room = await context.Rooms.SingleOrDefaultAsync(a => a.Id == id);
            if (room == null) { return BadRequest("Nope újra!"); }

            context.Rooms.Remove(room);
            await context.SaveChangesAsync();

            return Ok("Nope!");
        }
    }
}
