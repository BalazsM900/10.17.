﻿using Microsoft.AspNetCore.Identity;

namespace WebAPI_Computer.Entities
{
    public class ApplicationUser : IdentityUser
    {
    }
}
