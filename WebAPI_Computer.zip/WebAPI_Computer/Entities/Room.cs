﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI_Computer.Entities
{
    public class Room
    {
        [Key]
        public int Id { get; set; }
        [StringLength(255)]
        public string? Name { get; set; }
        public int Capacity { get; set; }
        public string? UserId { get; set; }
        public virtual ApplicationUser? User { get; set; }
    }
}
