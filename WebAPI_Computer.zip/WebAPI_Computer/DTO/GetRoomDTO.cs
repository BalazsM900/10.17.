﻿namespace WebAPI_Computer.DTO
{
    public class GetRoomDTO
    {   
        public string Name { get; set; }
        public int Capacity { get; set; }
    }
}
