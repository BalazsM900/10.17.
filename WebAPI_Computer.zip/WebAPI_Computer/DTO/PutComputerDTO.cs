﻿namespace WebAPI_Computer.DTO
{
    public class PutComputerDTO
    {
        public string Model { get; set; }
        public DateTime ManufacturedDate { get; set; }
    }
}
