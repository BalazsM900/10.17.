﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI_Computer.DTO
{
    public class PostRegisterDTO
    {
        [Required]
        [EmailAddress]
        [DataType(DataType.EmailAddress)]
        public string? Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string? Password { get; set; }
    }
}
