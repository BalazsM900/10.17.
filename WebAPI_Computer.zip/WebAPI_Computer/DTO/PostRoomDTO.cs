﻿namespace WebAPI_Computer.DTO
{
    public class PostRoomDTO
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
        public int UserId { get; set; }
    }
}
