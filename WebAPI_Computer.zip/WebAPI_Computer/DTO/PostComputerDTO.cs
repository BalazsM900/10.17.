﻿namespace WebAPI_Computer.DTO
{
    public class PostComputerDTO
    {
        public string Model { get; set; }
        public DateTime ManufacturedDate { get; set; }
    }
}
