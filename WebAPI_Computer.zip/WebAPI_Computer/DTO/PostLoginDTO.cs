﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI_Computer.DTO
{
    public class PostLoginDTO
    {
        [Required]
        public string Username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
